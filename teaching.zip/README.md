# Social norms, control and punishment

The set of the following pretty standard games are intended for the course in UZH taught by Heiko Rauhut and Philipp
Chapkovski in Spring 2017.
