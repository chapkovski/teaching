# urls.py
from django.conf.urls import url
from otree.urls import urlpatterns

# urlpatterns.append(url(r'^my_view/$', 'my_module.my_view'))
