
def float_as_percentage(a):
        return int(a * 100)
